﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string data1;
        string data2;
        string data3;
        string data4;
        public Form1()
        {
            InitializeComponent();
            label7.Text = "0";
            label8.Text = "0";
            label9.Text = "0";
            label10.Text = "0";
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);
            trackBar1.Minimum = 0;
            trackBar1.Maximum = 4999;
            trackBar1.TickFrequency = 500;
            trackBar1.TickStyle = TickStyle.BottomRight;

            trackBar2.Minimum = 5001;
            trackBar2.Maximum = 10000;
            trackBar2.TickFrequency = 500;
            trackBar2.TickStyle = TickStyle.BottomRight;

            trackBar3.Minimum = 0;
            trackBar3.Maximum = 100;
            trackBar3.TickFrequency = 10;
            trackBar3.TickStyle = TickStyle.BottomRight;

            trackBar4.Minimum = 0;
            trackBar4.Maximum = 100;
            trackBar4.TickFrequency = 10;
            trackBar4.TickStyle = TickStyle.BottomRight;

        }

        private void button1_Click(object sender, EventArgs e)
        {   try
            {
                serialPort1.PortName = comboBox1.Text;
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);
                serialPort1.Open();
                progressBar1.Value = 100;
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message,"ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                progressBar1.Value = 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {  
             
                
                trackBar1.Visible = true;
                trackBar2.Visible = true;
                trackBar3.Visible = true;
                trackBar4.Visible = true;

            }
        }


        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label7.Text = trackBar1.Value.ToString();
            trackBar2.Visible = false;
            trackBar3.Visible = false;
            trackBar4.Visible = false;
            data1 = label7.Text;
            serialPort1.WriteLine(data1);



        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            label8.Text = trackBar2.Value.ToString();
            trackBar1.Visible = false;
            trackBar3.Visible = false;
            trackBar4.Visible = false;
            data2 = label8.Text;
            serialPort1.WriteLine(data2);
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            label9.Text = trackBar3.Value.ToString();
            trackBar2.Visible = false;
            trackBar1.Visible = false;
            trackBar4.Visible = false;
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            label10.Text = trackBar4.Value.ToString();
            trackBar2.Visible = false;
            trackBar3.Visible = false;
            trackBar1.Visible = false;
            data3 = label9.Text;
            serialPort1.WriteLine(data3);
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
